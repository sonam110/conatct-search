
<?php $__env->startSection('extracss'); ?>
  <style>
        
        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f9f9f9;
            font-weight: bold;
        }

        tr:nth-child(even) {
            background-color: #f7f7f7;
        }

        tr:hover {
            background-color: #eaeaea;
        }

        td:first-child {
            font-weight: bold;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <div class="container">
    <h6>Contact Details</h6>
    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Value</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Name</td>
                <td><?php echo e($contact->first_name); ?> <?php echo e($contact->last_name); ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><?php echo e($contact->email); ?></td>
            </tr>
            <tr>
                <td>Phone</td>
                <td><?php echo e($contact->phone); ?></td>
            </tr>
            <tr>
                <td>Address</td>
                <td><?php echo e($contact->address); ?></td>
            </tr>
            <tr>
                <td>City</td>
                <td><?php echo e($contact->city); ?></td>
            </tr>
            <tr>
                <td>State</td>
                <td><?php echo e($contact->state); ?></td>
            </tr>
            <tr>
                <td>Zipcode</td>
                <td><?php echo e($contact->zipcode); ?></td>
            </tr>
        </tbody>
    </table>
</div>
 

<?php $__env->stopSection(); ?>
<?php $__env->startSection('extrajs'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\contact-data\resources\views/contacts/show.blade.php ENDPATH**/ ?>